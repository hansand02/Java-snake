public class HovedSnake
{
    public static void main(final String[] array) {
        final ControllerSnake controllerSnake = new ControllerSnake();
    }
}